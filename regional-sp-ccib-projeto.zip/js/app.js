
(function(){

/* ============================= CONFIG ============================= */
const OWNER_PEDRO = '82340121';
const OWNER_PEDRO_NAME = 'Pedro Oliveira';
const HUBSPOT_PORTAL_ID = '48321673';
let HUBSPOT_SNAPSHOT = null;
const STAGES = ['Prospecção','Primeiro contato','Reunião','Oportunidade','Proposta','Negociação','Associação','Pós-venda'];
const STAGE_CONTATO = 'Apenas contato';
let APENAS_CONTATO = {};
function stageOf(c){ return (APENAS_CONTATO[c.id] && (!c.stage || c.stage==='Prospecção')) ? STAGE_CONTATO : c.stage; }
const STAGE_FROM_LIFECYCLE = {lead:'Prospecção',opportunity:'Oportunidade',customer:'Associação'};
const K = {
  registry:'ccibsp:registry', activities:'ccibsp:activities', eventos:'ccibsp:eventos', conexoes:'ccibsp:conexoes', meta:'ccibsp:meta'
};

/* ============================= STATE ============================= */
let ST = {
  registry: {},      // id -> {source:'pedro'|'rafaela'|'manual', responsavel:'pedro'|'rafaela', stage, cache:{n,ind,c,s,e,v,nc,nd,dm}, lastSynced, detail:{contacts,deals,loaded}}
  activities: [],    // {id,tipo:'reuniao'|'follow-up avulso',empresaId,empresaNome,data,participantesCCIB,participantesEmpresa,objetivo,resultado,proximaAcao,dataFollowUp,responsavel,status}
  eventos: [],
  conexoes: [],
  filters:{setor:'',status:'',resp:'',periodo:'0',busca:''},
  activeTab:'geral',
  syncing:false,
  lastSync:null,
  lastError:null,
  companyPage:0,
  companyPageSize:20,
  contactsPage:0,
};

/* ============================= STORAGE HELPERS ============================= */
// Neste site hospedado (fora do ambiente do Claude), não existe a API window.storage.
// Usamos localStorage do navegador: funciona perfeitamente, mas é PRIVADO por navegador/dispositivo —
// o que o Pedro salva aqui não aparece automaticamente no computador da Rafaela, e vice-versa.
// Para dados de verdade compartilhados entre a equipe, veja a seção "Próximo passo" no README.md.
async function loadKey(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(raw==null) return fallback;
    return JSON.parse(raw);
  }catch(e){ return fallback; }
}
async function saveKey(key, value){
  try{ localStorage.setItem(key, JSON.stringify(value)); }catch(e){ console.error('storage set failed', key, e); }
}
async function loadAll(){
  ST.registry = await loadKey(K.registry, {});
  ST.activities = await loadKey(K.activities, []);
  ST.eventos = await loadKey(K.eventos, []);
  ST.conexoes = await loadKey(K.conexoes, []);
  const meta = await loadKey(K.meta, {});
  ST.lastSync = meta.lastSync || null;
}
function persistRegistry(){ saveKey(K.registry, ST.registry); }
function persistActivities(){ saveKey(K.activities, ST.activities.filter(a=>!a.seed)); }
function persistEventos(){ saveKey(K.eventos, ST.eventos.filter(e=>!e.seed)); }
function persistConexoes(){ saveKey(K.conexoes, ST.conexoes); }
function persistMeta(){ saveKey(K.meta, {lastSync: ST.lastSync}); }

/* ============================= HUBSPOT DATA (via Claude snapshot) ============================= */
// Os dados abaixo foram buscados diretamente no HubSpot pelo Claude nesta conversa (não pelo navegador).
// Isso evita o problema de autenticação que impedia o botão "Sincronizar" de funcionar.
// Para atualizar: peça ao Claude, no chat, "atualize os dados do HubSpot no dashboard".

function upsertCompanyToRegistry(id, data, source){
  const existing = ST.registry[id] || {};
  ST.registry[id] = {
    source: existing.source || source,
    responsavel: existing.responsavel || (source==='rafaela' ? 'rafaela':'pedro'),
    stage: existing.stage || STAGE_FROM_LIFECYCLE[data.s] || 'Prospecção',
    cache: {n:data.n,ind:data.ind,c:data.c,s:data.s,e:data.e,v:Number(data.v||0),nc:Number(data.nc||0),nd:Number(data.nd||0),dm:data.dm,url:data.url,
      assocType:data.assocType||null, assocStatus:data.assocStatus||null, assocValue:data.assocValue||null, assocWon:!!data.assocWon, wonNoSync:!!data.wonNoSync, dealUrl:data.dealUrl||null},
    note: data.note || null,
    lastSynced: HUBSPOT_SNAPSHOT.fetchedAt,
  };
}

let kpiCache = null;

function applySnapshot(){
  Object.entries(HUBSPOT_SNAPSHOT.companies).forEach(([id, data])=>{
    upsertCompanyToRegistry(id, data, 'pedro');
  });
  kpiCache = HUBSPOT_SNAPSHOT.kpi;
  ST.lastSync = new Date(HUBSPOT_SNAPSHOT.fetchedAt).getTime();
  persistRegistry();
  persistMeta();
}

function fmtSyncTag(){
  if(!ST.lastSync) return 'dados do HubSpot ainda não carregados';
  const d = new Date(ST.lastSync);
  return `dados do HubSpot de ${d.toLocaleDateString('pt-BR')} · peça ao Claude para atualizar`;
}

function openSyncInfoModal(){
  const root = document.getElementById('modal-root');
  root.innerHTML = `<div class="modal-overlay" id="ovs"><div class="modal">
    <div class="modal-head"><h3>Como atualizar os dados do HubSpot</h3><button class="close-x" id="closes">✕</button></div>
    <div class="modal-body">
      <p>Este site não consegue se autenticar diretamente no HubSpot a partir do navegador — por isso os dados de empresas e negócios ficam num arquivo separado (<code>data/snapshot.json</code>) que é atualizado de tempos em tempos.</p>
      <p><b>Para atualizar:</b> abra uma conversa com o Claude e peça algo como:</p>
      <p class="hint" style="background:#F8F9FB;padding:10px;border-radius:8px;">"Atualize os dados do HubSpot no dashboard da Regional São Paulo"</p>
      <p>O Claude vai gerar um novo <code>data/snapshot.json</code>. Substitua esse arquivo no repositório do GitHub (commit + push) e o Vercel publica a atualização automaticamente em segundos.</p>
      <p class="hint">Reuniões, follow-ups, eventos, conexões e pipeline ficam salvos no seu navegador — veja o aviso sobre isso na página inicial do projeto (README).</p>
    </div>
    <div class="modal-foot"><button class="btn btn-primary" id="closes2">Entendi</button></div>
  </div></div>`;
  const close = ()=> root.innerHTML='';
  document.getElementById('closes').onclick = close;
  document.getElementById('closes2').onclick = close;
  document.getElementById('ovs').addEventListener('click', e=>{ if(e.target.id==='ovs') close(); });
}
function setSyncTag(html){ const el=document.getElementById('sync-tag'); if(el) el.innerHTML = html; }

/* ============================= UTIL ============================= */
function uid(){ return 'x'+Math.random().toString(36).slice(2,10); }
function fmtCurrency(v){ return 'US$ ' + Number(v||0).toLocaleString('pt-BR',{maximumFractionDigits:0}); }
function parseDate(d){
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d||'');
  return m ? new Date(Number(m[1]), Number(m[2])-1, Number(m[3])) : new Date(d);
}
function fmtDate(d){ if(!d) return '—'; const dt=parseDate(d); if(isNaN(dt)) return d; return dt.toLocaleDateString('pt-BR'); }
function daysBetween(d){
  const a = parseDate(d), t = new Date();
  const target = new Date(a.getFullYear(), a.getMonth(), a.getDate());
  const today = new Date(t.getFullYear(), t.getMonth(), t.getDate());
  return Math.round((target - today)/86400000);
}
function todayISO(){
  const t = new Date(), pad = n=>String(n).padStart(2,'0');
  return `${t.getFullYear()}-${pad(t.getMonth()+1)}-${pad(t.getDate())}`;
}
function fmtDayMonth(d){ const m=/^\d{4}-(\d{2})-(\d{2})$/.exec(d||''); return m ? `${m[2]}/${m[1]}` : '—'; }
const MESES=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
function reunioesAll(){ return ST.activities.filter(a=>a.tipo==='reuniao'||a.tipo==='evento externo'); }
function reuniaoStatus(a){ if(a.seed) return (a.dataFim||a.data) < todayISO() ? 'realizada' : 'agendada'; return a.status==='agendado' ? 'agendada' : 'realizada'; }
function eventoRealizado(ev){ return !!ev.data && ev.data < todayISO(); }
function evDataLabel(ev){ return ev.data ? fmtDayMonth(ev.data) : 'Nov'; }
function proximosEventos(){ return ST.eventos.filter(e=>!eventoRealizado(e)).sort((a,b)=>(a.data||'9999').localeCompare(b.data||'9999')); }
function eventosRealizados(){ return ST.eventos.filter(eventoRealizado).sort((a,b)=>(b.data||'').localeCompare(a.data||'')); }
function escapeHtml(s){ return (s||'').toString().replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function companiesList(){
  return Object.entries(ST.registry).map(([id,r])=>({id, ...r}));
}
function applyFilters(list){
  const f = ST.filters;
  return list.filter(c=>{
    if(f.setor && (c.cache?.ind||'')!==f.setor) return false;
    if(f.status && (c.cache?.s||'lead')!==f.status) return false;
    if(f.resp && c.responsavel!==f.resp) return false;
    if(f.busca && !(c.cache?.n||'').toLowerCase().includes(f.busca.toLowerCase())) return false;
    return true;
  });
}
function populateSetorOptions(){
  const sel = document.getElementById('f-setor');
  const current = sel.value;
  const setores = Array.from(new Set(companiesList().map(c=>c.cache?.ind).filter(Boolean))).sort();
  sel.innerHTML = '<option value="">Todos</option>' + setores.map(s=>`<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('');
  sel.value = current;
}

/* ============================= NAV / TABS ============================= */
const NAV = [
  {id:'geral', label:'Visão Geral', icon:'grid'},
  {id:'associados', label:'Associados', icon:'star'},
  {id:'empresas', label:'Empresas', icon:'building'},
  {id:'contatos', label:'Contatos', icon:'users'},
  {id:'atividades', label:'Reuniões', icon:'calendar'},
  {id:'pipeline', label:'Pipeline', icon:'columns'},
  {id:'followups', label:'Follow-ups', icon:'clock'},
  {id:'eventos', label:'Eventos', icon:'flag'},
  {id:'conexoes', label:'Conexões', icon:'share'},
];
const ICONS = {
  grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  star:'<path d="M12 2l2.9 6.6 7.1.7-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7-5.4-4.7 7.1-.7z"/>',
  building:'<rect x="4" y="3" width="9" height="18"/><rect x="13" y="8" width="7" height="13"/><line x1="7" y1="7" x2="7" y2="7.01"/><line x1="10" y1="7" x2="10" y2="7.01"/><line x1="7" y1="11" x2="7" y2="11.01"/><line x1="10" y1="11" x2="10" y2="11.01"/>',
  users:'<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17.5" cy="9" r="2.6"/><path d="M15 14.2c2.9.3 5 2.6 5 5.8"/>',
  calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="16" y1="2" x2="16" y2="6"/>',
  columns:'<rect x="3" y="4" width="5" height="16" rx="1"/><rect x="9.5" y="4" width="5" height="10" rx="1"/><rect x="16" y="4" width="5" height="13" rx="1"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.3 3.3"/>',
  flag:'<line x1="5" y1="21" x2="5" y2="3"/><path d="M5 4h13l-3 4.5L18 13H5"/>',
  share:'<circle cx="6" cy="12" r="2.6"/><circle cx="18" cy="6" r="2.6"/><circle cx="18" cy="18" r="2.6"/><path d="M8.3 10.8 15.7 7.2M8.3 13.2l7.4 3.6"/>',
};
function svgIcon(name){ return `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name]}</svg>`; }

function renderNav(){
  const nav = document.getElementById('nav');
  nav.innerHTML = NAV.map(n=>`<div class="nav-item ${ST.activeTab===n.id?'active':''}" data-tab="${n.id}">${svgIcon(n.icon)}<span>${n.label}</span></div>`).join('');
  nav.querySelectorAll('.nav-item').forEach(el=>{
    el.addEventListener('click', ()=>{ ST.activeTab = el.dataset.tab; renderAll(); });
  });
}

const TAB_TITLES = {
  geral:['Visão Geral','KPIs e panorama da atuação da Regional São Paulo'],
  associados:['Associados','Empresas associadas à CCIB desenvolvidas pela Regional'],
  empresas:['Empresas','Base viva de empresas — sincronizada com o HubSpot'],
  contatos:['Contatos','Pessoas relacionadas às empresas da Regional'],
  atividades:['Reuniões & Atividades','Histórico e agenda de reuniões com empresas'],
  pipeline:['Pipeline da Regional','Funil próprio, do primeiro contato à associação'],
  followups:['Follow-ups','O que precisa de ação agora'],
  eventos:['Eventos & Iniciativas','Missões, encontros e eventos organizados pela Regional'],
  conexoes:['Conexões Empresariais','Pontes feitas entre empresas da rede CCIB'],
};

function renderAll(){
  renderNav();
  const [title,sub] = TAB_TITLES[ST.activeTab];
  document.getElementById('page-title').textContent = title;
  document.getElementById('page-sub').textContent = sub;
  document.getElementById('sync-tag').innerHTML = ST.syncing ? 'sincronizando <span class="loading-dot"></span>' : fmtSyncTag();
  populateSetorOptions();

  const tabs = document.getElementById('tabs');
  tabs.innerHTML = `
    <div class="tab ${ST.activeTab==='geral'?'active':''}" id="tab-geral"></div>
    <div class="tab ${ST.activeTab==='associados'?'active':''}" id="tab-associados"></div>
    <div class="tab ${ST.activeTab==='empresas'?'active':''}" id="tab-empresas"></div>
    <div class="tab ${ST.activeTab==='contatos'?'active':''}" id="tab-contatos"></div>
    <div class="tab ${ST.activeTab==='atividades'?'active':''}" id="tab-atividades"></div>
    <div class="tab ${ST.activeTab==='pipeline'?'active':''}" id="tab-pipeline"></div>
    <div class="tab ${ST.activeTab==='followups'?'active':''}" id="tab-followups"></div>
    <div class="tab ${ST.activeTab==='eventos'?'active':''}" id="tab-eventos"></div>
    <div class="tab ${ST.activeTab==='conexoes'?'active':''}" id="tab-conexoes"></div>
  `;
  if(ST.activeTab==='geral') renderGeral();
  if(ST.activeTab==='associados') renderAssociados();
  if(ST.activeTab==='empresas') renderCompaniesTable();
  if(ST.activeTab==='contatos') renderContatos();
  if(ST.activeTab==='atividades') renderAtividades();
  if(ST.activeTab==='pipeline') renderPipeline();
  if(ST.activeTab==='followups') renderFollowups();
  if(ST.activeTab==='eventos') renderEventos();
  if(ST.activeTab==='conexoes') renderConexoes();
}

/* ============================= VISÃO GERAL ============================= */
function renderGeral(){
  const el = document.getElementById('tab-geral'); if(!el) return;
  const list = companiesList();
  const associados = list.filter(c=>c.cache?.s==='customer').length;
  const negociacao = list.filter(c=>c.cache?.s==='opportunity').length;
  const prospeccao = list.filter(c=>c.cache?.s==='lead').length;
  const perdidas = list.filter(c=>c.cache?.s==='lost').length;
  const totalEmpresas = list.length;

  const reunioes = ST.activities.filter(a=>a.tipo==='reuniao');
  const activities7 = reunioes.filter(a=>a.data && daysBetween(a.data)<=0 && daysBetween(a.data)>=-7 && reuniaoStatus(a)==='realizada').length;
  const futuras = reunioes.filter(a=>a.data && (daysBetween(a.data)>0 || reuniaoStatus(a)==='agendada')).length;
  const followLate = ST.activities.filter(a=>a.dataFollowUp && daysBetween(a.dataFollowUp) < 0 && a.status!=='concluído').length;
  const followSoon = ST.activities.filter(a=>a.dataFollowUp && daysBetween(a.dataFollowUp) >= 0 && daysBetween(a.dataFollowUp) <=7 && a.status!=='concluído').length;

  const kpiRows = [
    {label:'Associados', value: kpiCache ? kpiCache.customer : associados, sub:'lifecyclestage: customer', tab:'associados', cls:'good'},
    {label:'Em negociação', value: kpiCache ? kpiCache.opportunity : negociacao, sub:'oportunidades abertas', tab:'empresas', cls:'accent'},
    {label:'Negócio perdido', value: kpiCache && kpiCache.lost!=null ? kpiCache.lost : perdidas, sub:'perdido no HubSpot', tab:'empresas', cls: perdidas>0?'warn':''},
    {label:'Em prospecção', value: kpiCache ? kpiCache.lead : prospeccao, sub:'leads da Regional', tab:'empresas', cls:''},
    {label:'Empresas sincronizadas', value: totalEmpresas, sub:'total no registro', tab:'empresas', cls:''},
    {label:'Reuniões (7 dias)', value: activities7, sub:'realizadas na semana', tab:'atividades', cls:''},
    {label:'Reuniões futuras', value: futuras, sub:'agendadas', tab:'atividades', cls:''},
    {label:'Follow-ups atrasados', value: followLate, sub:'ação necessária', tab:'followups', cls: followLate>0?'warn':'good'},
    {label:'Follow-ups próximos 7d', value: followSoon, sub:'preparar contato', tab:'followups', cls:'accent'},
    {label:'Eventos realizados', value: eventosRealizados().length, sub:'iniciativas da Regional', tab:'eventos', cls:''},
    {label:'Próximos eventos', value: proximosEventos().length, sub: proximosEventos().length? 'próximo: '+(proximosEventos()[0].data?fmtDayMonth(proximosEventos()[0].data):'data a definir') : 'nenhum agendado', tab:'eventos', cls:'accent'},
    {label:'Conexões feitas', value: ST.conexoes.length, sub:'empresa ↔ empresa', tab:'conexoes', cls:''},
    {label:'Negócios abertos', value: kpiCache ? kpiCache.dealsAbertos : '—', sub: kpiCache? fmtCurrency(kpiCache.valorAberto) : 'sincronize p/ ver', tab:'empresas', cls:'accent'},
    {label:'Negócios ganhos', value: kpiCache ? kpiCache.dealsGanhos : '—', sub: kpiCache? fmtCurrency(kpiCache.valorGanho) : 'sincronize p/ ver', tab:'empresas', cls:'good'},
  ];

  el.innerHTML = `
    <div class="kpi-grid">
      ${kpiRows.map(k=>`<div class="kpi-card ${k.cls}" data-goto="${k.tab}"><div class="label">${k.label}</div><div class="value mono">${k.value}</div><div class="sub">${k.sub}</div></div>`).join('')}
    </div>
    <div class="two-col">
      <div class="panel">
        <div class="panel-head"><h3>Reuniões recentes</h3><span class="link-btn" data-goto2="atividades">ver todas →</span></div>
        <div class="panel-body">${renderMiniActivityList(ST.activities.filter(a=>a.tipo==='reuniao'&&reuniaoStatus(a)==='realizada').sort((a,b)=>(b.data||'').localeCompare(a.data||'')).slice(0,5))}</div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>Follow-ups em aberto</h3><span class="link-btn" data-goto2="followups">ver todos →</span></div>
        <div class="panel-body">${renderMiniFollowList()}</div>
      </div>
    </div>
    <div class="panel">
      <div class="panel-head"><h3>Próximos eventos</h3><span class="link-btn" data-goto2="eventos">ver todos →</span></div>
      <div class="panel-body">${renderMiniEventos()}</div>
    </div>`;
  el.querySelectorAll('[data-goto]').forEach(c=>c.addEventListener('click', ()=>{ ST.activeTab=c.dataset.goto; renderAll(); }));
  el.querySelectorAll('[data-goto2]').forEach(c=>c.addEventListener('click', ()=>{ ST.activeTab=c.dataset.goto2; renderAll(); }));
}
function renderMiniEventos(){
  const items = proximosEventos().slice(0,4);
  if(!items.length) return '<div class="empty">Nenhum evento agendado. Adicione em "Eventos".</div>';
  return items.map(ev=>`<div class="mini-row"><span class="k"><b class="mono">${evDataLabel(ev)}</b> · ${escapeHtml(ev.nome)}${ev.data?'':' <i>('+escapeHtml(ev.dataPrevista||'sem data')+')</i>'}</span><span class="v" style="font-weight:400;">${escapeHtml(ev.local||'')}</span></div>`).join('');
}
function renderMiniActivityList(items){
  if(!items.length) return '<div class="empty">Nenhuma reunião registrada ainda. Adicione em "Reuniões".</div>';
  return items.map(a=>`<div class="mini-row"><span class="k">${escapeHtml(a.empresaNome)} — ${fmtDate(a.data)}${a.horario?' '+a.horario:''}</span><span class="v">${escapeHtml(a.responsavel||'')}</span></div>`).join('');
}
function renderMiniFollowList(){
  const items = ST.activities.filter(a=>a.dataFollowUp && a.status!=='concluído').sort((a,b)=>new Date(a.dataFollowUp)-new Date(b.dataFollowUp)).slice(0,5);
  if(!items.length) return '<div class="empty">Nenhum follow-up pendente 🎉</div>';
  return items.map(a=>{
    const d = daysBetween(a.dataFollowUp);
    const tag = d<0? '<span class="tag tag-late">atrasado</span>' : d<=2? '<span class="tag tag-soon">em breve</span>' : '<span class="tag tag-ok">agendado</span>';
    return `<div class="mini-row"><span class="k">${escapeHtml(a.empresaNome)} · ${fmtDate(a.dataFollowUp)}</span><span class="v">${tag}</span></div>`;
  }).join('');
}

/* ============================= ASSOCIADOS ============================= */
function fmtAssoc(c){
  if(!c.cache.assocType) return '<span class="hint">—</span>';
  const st = c.cache.assocStatus;
  const cls = st==='lost' ? 'tag-late' : st==='open' ? 'tag-soon' : 'tag-ok';
  const lbl = st==='lost' ? 'negócio perdido' : st==='open' ? 'negócio aberto' : st==='won' ? 'negócio ganho' : '';
  return `<span class="tag ${cls}">${escapeHtml(c.cache.assocType)}</span><div class="mono" style="margin-top:2px;">${fmtCurrency(c.cache.assocValue)}</div>${lbl? `<div class="hint">${lbl}</div>`:''}`;
}
function wonBadge(c){
  if(!c.cache.wonNoSync) return '';
  return ` <span class="tag tag-late" title="Negócio ganho no HubSpot, mas o status da empresa ainda não foi atualizado para Associado">⚠ negócio ganho</span>`;
}
function renderAssociados(){
  const el = document.getElementById('tab-associados'); if(!el) return;
  const wonNotSynced = applyFilters(companiesList()).filter(c=>c.cache?.wonNoSync);
  const list = applyFilters(companiesList()).filter(c=>c.cache?.s==='customer');
  el.innerHTML = `
    ${wonNotSynced.length? `<div class="error-banner" style="background:var(--saffron-100);border-color:#EBCB8E;color:#7A5A16;">
      <div style="flex:1;"><b>${wonNotSynced.length} empresa(s) com negócio ganho, mas status ainda "Lead" no HubSpot</b>
      ${wonNotSynced.map(c=>escapeHtml(c.cache.n)).join(', ')} — vale atualizar o lifecyclestage delas no HubSpot para "Customer".</div></div>` : ''}
    <div class="panel"><div class="panel-head"><h3>Associados (${list.length})</h3><span class="hint">status HubSpot: lifecyclestage = customer</span></div>
    <div class="panel-body">
    ${list.length? `<table><thead><tr><th>Empresa</th><th>Setor</th><th>País</th><th>Associação</th><th>Contatos</th><th>Responsável</th></tr></thead><tbody>
      ${list.map(c=>`<tr class="clickable" data-open="${c.id}"><td><b>${escapeHtml(c.cache.n)}</b>${c.note? `<div class="hint">${escapeHtml(c.note)}</div>`:''}</td><td>${escapeHtml(c.cache.ind||'—')}</td><td>${escapeHtml(c.cache.c||'—')}</td><td>${fmtAssoc(c)}</td><td>${c.cache.nc}</td><td><span class="badge-resp">${c.responsavel}</span></td></tr>`).join('')}
    </tbody></table>` : `<div class="empty">Nenhum associado encontrado com os filtros atuais. Sincronize o HubSpot ou ajuste os filtros.</div>`}
    </div></div>`;
  el.querySelectorAll('[data-open]').forEach(r=>r.addEventListener('click', ()=>openCompanyDrawer(r.dataset.open)));
}

/* ============================= EMPRESAS ============================= */
function renderCompaniesTable(){
  const el = document.getElementById('tab-empresas'); if(!el) return;
  const list = applyFilters(companiesList()).sort((a,b)=>(a.cache?.n||'').localeCompare(b.cache?.n||''));
  el.innerHTML = `
    <div class="panel">
      <div class="panel-head">
        <h3>Empresas (${list.length})</h3>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-accent btn-sm" id="btn-add-rafaela">+ Adicionar empresa (Rafaela)</button>
        </div>
      </div>
      <div class="panel-body">
      ${list.length? `<table><thead><tr><th>Empresa</th><th>Setor</th><th>País</th><th>Status</th><th>Associação</th><th>Responsável</th></tr></thead><tbody>
        ${list.map(c=>`<tr class="clickable" data-open="${c.id}">
          <td><b>${escapeHtml(c.cache.n)}</b>${c.cache.dm?`<div class="hint">${escapeHtml(c.cache.dm)}</div>`:''}${c.note?`<div class="hint">${escapeHtml(c.note)}</div>`:''}</td>
          <td>${escapeHtml(c.cache.ind||'—')}</td><td>${escapeHtml(c.cache.c||'—')}</td>
          <td><span class="tag tag-${c.cache.s||'lead'}">${labelStatus(c.cache.s)}</span>${wonBadge(c)}</td>
          <td>${fmtAssoc(c)}</td>
          <td><span class="badge-resp">${c.responsavel}</span></td>
        </tr>`).join('')}
      </tbody></table>` : `<div class="empty">Nenhuma empresa carregada ainda.</div>`}
      </div>
    </div>`;
  el.querySelectorAll('[data-open]').forEach(r=>r.addEventListener('click', ()=>openCompanyDrawer(r.dataset.open)));
  const addBtn = document.getElementById('btn-add-rafaela');
  if(addBtn) addBtn.addEventListener('click', openAddCompanyModal);
}
function labelStatus(s){ return s==='customer'?'Associado': s==='opportunity'?'Em negociação': s==='lost'?'Negócio perdido':'Prospecção'; }


function openAddCompanyModal(){
  const root = document.getElementById('modal-root');
  root.innerHTML = `
  <div class="modal-overlay" id="ov1">
    <div class="modal">
      <div class="modal-head"><h3>Adicionar empresa à Regional (Rafaela)</h3><button class="close-x" id="close1">✕</button></div>
      <div class="modal-body">
        <p class="hint">Busque entre as empresas já carregadas do HubSpot, ou cadastre uma empresa nova (fora do HubSpot) manualmente.</p>
        <div class="fld"><input type="text" id="search-input" placeholder="Digite o nome da empresa..."/></div>
        <div id="search-results" style="margin-top:8px;max-height:220px;overflow:auto;"></div>
        <div style="margin-top:14px;border-top:1px solid var(--border);padding-top:14px;">
          <button class="link-btn" id="toggle-manual">+ Não encontrei — cadastrar manualmente</button>
          <div id="manual-form" style="display:none;margin-top:10px;">
            <div class="form-grid">
              <div class="fld" style="grid-column:1/-1;"><label>Nome da empresa</label><input type="text" id="man-nome"/></div>
              <div class="fld"><label>Setor</label><input type="text" id="man-setor"/></div>
              <div class="fld"><label>País</label><input type="text" id="man-pais"/></div>
              <div class="fld"><label>Status</label><select id="man-status"><option value="lead">Prospecção</option><option value="opportunity">Em negociação</option><option value="customer">Associado</option></select></div>
            </div>
            <button class="btn btn-accent btn-sm" id="man-save" style="margin-top:8px;">Cadastrar empresa</button>
            <div class="hint" style="margin-top:6px;">Esta empresa não existe no HubSpot ainda — fica registrada só aqui no painel, compartilhada entre vocês.</div>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  const close = ()=> root.innerHTML='';
  document.getElementById('close1').onclick = close;
  document.getElementById('ov1').addEventListener('click', e=>{ if(e.target.id==='ov1') close(); });
  document.getElementById('toggle-manual').onclick = ()=>{
    const f = document.getElementById('manual-form');
    f.style.display = f.style.display==='none' ? 'block' : 'none';
  };
  document.getElementById('man-save').onclick = ()=>{
    const nome = document.getElementById('man-nome').value.trim();
    if(!nome){ alert('Informe o nome da empresa.'); return; }
    const id = uid();
    upsertCompanyToRegistry(id, {n:nome, ind:document.getElementById('man-setor').value, c:document.getElementById('man-pais').value, s:document.getElementById('man-status').value, nc:0, nd:0, v:0, dm:null, url:null}, 'rafaela');
    ST.registry[id].responsavel = 'rafaela';
    persistRegistry(); close(); renderAll();
  };
  const input = document.getElementById('search-input');
  function runSearch(){
    const q = input.value.trim().toLowerCase();
    const box = document.getElementById('search-results');
    if(q.length<2){ box.innerHTML=''; return; }
    const items = companiesList().filter(c=>c.cache.n.toLowerCase().includes(q)).slice(0,12);
    box.innerHTML = items.length ? items.map(it=>
      `<div class="search-result" data-id="${it.id}">
        <span>${escapeHtml(it.cache.n)} <span class="hint">${escapeHtml(it.cache.ind||'')}</span></span><span class="link-btn">marcar p/ Rafaela</span></div>`
    ).join('') : '<div class="hint">Nenhuma empresa carregada com esse nome — use o cadastro manual abaixo.</div>';
    box.querySelectorAll('.search-result').forEach(r=>r.addEventListener('click', ()=>{
      ST.registry[r.dataset.id].responsavel = 'rafaela';
      persistRegistry(); close(); renderAll();
    }));
  }
  input.addEventListener('input', runSearch);
}

/* ============================= COMPANY DRAWER ============================= */
function openCompanyDrawer(id){
  const c = ST.registry[id]; if(!c) return;
  const root = document.getElementById('drawer-root');
  root.innerHTML = `
  <div class="drawer-overlay" id="ov-drawer"></div>
  <div class="drawer">
    <div class="drawer-head">
      <div class="eyebrow">${labelStatus(c.cache.s)} · ${escapeHtml(c.cache.ind||'setor não informado')}</div>
      <h3>${escapeHtml(c.cache.n)}</h3>
      <div class="hint">${escapeHtml(c.cache.c||'')} ${c.cache.dm?'· '+escapeHtml(c.cache.dm):''}</div>
      ${c.cache.url? `<a href="${c.cache.url}" target="_blank" rel="noopener" class="btn btn-ghost btn-sm" style="margin-top:8px;display:inline-block;">Abrir no HubSpot ↗</a>` : ''}
      ${!c.cache.url && c.cache.dealUrl? `<a href="${c.cache.dealUrl}" target="_blank" rel="noopener" class="btn btn-ghost btn-sm" style="margin-top:8px;display:inline-block;">Abrir negócio no HubSpot ↗</a>` : ''}
    </div>
    <div class="drawer-section">
      <h4>Resumo</h4>
      <div class="mini-row"><span class="k">Responsável</span><span class="v">${c.responsavel}</span></div>
      <div class="mini-row"><span class="k">Etapa do funil da Regional</span><span class="v">${stageOf(c)}</span></div>
      <div class="mini-row"><span class="k">Negócio no HubSpot</span><span class="v">${{won:'Ganho',open:'Aberto',lost:'Perdido'}[c.cache.assocStatus]||'—'}</span></div>
      <div class="mini-row"><span class="k">Tipo de associação</span><span class="v">${c.cache.assocType? escapeHtml(c.cache.assocType) : '—'}</span></div>
      <div class="mini-row"><span class="k">Valor da associação</span><span class="v">${c.cache.assocValue!=null? fmtCurrency(c.cache.assocValue) : '—'}</span></div>
      <div class="mini-row"><span class="k">Nº contatos (HubSpot)</span><span class="v">${c.cache.nc}</span></div>
      <div class="mini-row"><span class="k">Nº negócios (HubSpot)</span><span class="v">${c.cache.nd}</span></div>
      ${c.note? `<div class="hint" style="margin-top:8px;">${escapeHtml(c.note)}</div>` : ''}
      ${c.cache.url? `<div class="hint" style="margin-top:8px;">Para ver a lista completa de contatos e negócios, abra a empresa no HubSpot pelo link acima.</div>` : (!c.cache.dealUrl ? `<div class="hint" style="margin-top:8px;">Empresa cadastrada manualmente — não existe no HubSpot.</div>` : '')}
    </div>
    <div class="drawer-section">
      <h4>Reuniões registradas</h4>
      <div id="drawer-activities"></div>
      <button class="btn btn-ghost btn-sm" style="margin-top:8px;" id="drawer-add-meeting">+ Registrar reunião</button>
    </div>
  </div>`;
  document.getElementById('ov-drawer').onclick = ()=> root.innerHTML='';
  renderDrawerActivities(id);
  document.getElementById('drawer-add-meeting').onclick = ()=> openMeetingModal(id, c.cache.n);
}
function renderDrawerActivities(companyId){
  const box = document.getElementById('drawer-activities'); if(!box) return;
  const items = ST.activities.filter(a=>a.empresaId===companyId).sort((a,b)=>(b.data||'').localeCompare(a.data||''));
  box.innerHTML = items.length ? items.map(a=>`<div class="mini-row"><span class="k">${fmtDate(a.data)} — ${escapeHtml(a.titulo||a.objetivo||'reunião')}</span><span class="v" style="font-weight:400;">${escapeHtml(a.responsavel||'')}</span></div>`).join('') : '<div class="hint">Nenhuma reunião registrada com esta empresa ainda.</div>';
}

/* ============================= CONTATOS ============================= */
function renderContatos(){
  const el = document.getElementById('tab-contatos'); if(!el) return;
  const list = applyFilters(companiesList());
  el.innerHTML = `<div class="panel"><div class="panel-head"><h3>Contatos por empresa</h3><span class="hint">clique numa empresa para ver os contatos ao vivo do HubSpot</span></div>
    <div class="panel-body">
    ${list.length? `<table><thead><tr><th>Empresa</th><th>Setor</th><th>Contatos (HubSpot)</th><th>Responsável</th></tr></thead><tbody>
      ${list.filter(c=>c.cache.nc>0).sort((a,b)=>b.cache.nc-a.cache.nc).map(c=>`<tr class="clickable" data-open="${c.id}"><td><b>${escapeHtml(c.cache.n)}</b></td><td>${escapeHtml(c.cache.ind||'—')}</td><td>${c.cache.nc}</td><td><span class="badge-resp">${c.responsavel}</span></td></tr>`).join('')}
    </tbody></table>` : '<div class="empty">Sincronize o HubSpot para ver os contatos das empresas.</div>'}
    </div></div>`;
  el.querySelectorAll('[data-open]').forEach(r=>r.addEventListener('click', ()=>openCompanyDrawer(r.dataset.open)));
}

/* ============================= ATIVIDADES / REUNIÕES ============================= */
let CAL = {y:null, m:null, sel:null, view:'calendario'};
function renderAtividades(){
  const el = document.getElementById('tab-atividades'); if(!el) return;
  if(CAL.y===null){ const t=new Date(); CAL.y=t.getFullYear(); CAL.m=t.getMonth(); }
  const items = reunioesAll().sort((a,b)=>(b.data||'').localeCompare(a.data||'')||(b.horario||'').localeCompare(a.horario||''));
  const toggle = `<span class="pill-btn ${CAL.view==='calendario'?'active':''}" data-view="calendario">Calendário</span> <span class="pill-btn ${CAL.view==='lista'?'active':''}" data-view="lista">Lista</span>`;
  el.innerHTML = `<div class="panel">
    <div class="panel-head"><h3>Reuniões (${items.length})</h3><div style="display:flex;gap:8px;align-items:center;">${toggle}<button class="btn btn-accent btn-sm" id="btn-new-meeting">+ Registrar reunião</button></div></div>
    <div class="panel-body">${CAL.view==='calendario' ? renderCalendar(items) : renderMeetingTable(items)}</div></div>`;
  document.getElementById('btn-new-meeting').onclick = ()=> openMeetingModal(null, '');
  el.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{ CAL.view=b.dataset.view; renderAtividades(); });
  el.querySelectorAll('[data-cal-nav]').forEach(b=>b.onclick=()=>{
    const n=b.dataset.calNav;
    if(n==='hoje'){ const t=new Date(); CAL.y=t.getFullYear(); CAL.m=t.getMonth(); CAL.sel=todayISO(); }
    else { CAL.m += Number(n); if(CAL.m<0){CAL.m=11;CAL.y--;} if(CAL.m>11){CAL.m=0;CAL.y++;} CAL.sel=null; }
    renderAtividades();
  });
  el.querySelectorAll('[data-cal-day]').forEach(c=>c.onclick=()=>{ CAL.sel=c.dataset.calDay; renderAtividades(); });
  el.querySelectorAll('[data-meet]').forEach(c=>c.onclick=(e)=>{ e.stopPropagation(); const a=items.find(x=>x.id===c.dataset.meet); if(a) openMeetingDetail(a); });
}
function meetingsOnDay(items, iso){ return items.filter(a=>a.data && a.data<=iso && (a.dataFim||a.data)>=iso).sort((a,b)=>(a.horario||'').localeCompare(b.horario||'')); }
function renderCalendar(items){
  const y=CAL.y, m=CAL.m, pad=n=>String(n).padStart(2,'0');
  const first=new Date(y,m,1), start=first.getDay(), days=new Date(y,m+1,0).getDate(), today=todayISO();
  let cells='';
  for(let i=0;i<start;i++) cells+='<div class="cal-cell empty"></div>';
  for(let d=1; d<=days; d++){
    const iso=`${y}-${pad(m+1)}-${pad(d)}`, ms=meetingsOnDay(items, iso);
    cells+=`<div class="cal-cell ${iso===today?'today':''} ${iso===CAL.sel?'sel':''}" data-cal-day="${iso}"><div class="cal-d">${d}</div>
      ${ms.slice(0,3).map(a=>`<div class="cal-ev ${reuniaoStatus(a)} ${a.tipo==='evento externo'?'ext':''}" data-meet="${a.id}" title="${escapeHtml(a.titulo||a.empresaNome)}">${a.horario&&a.data===iso?`<b>${a.horario}</b> `:''}${escapeHtml(a.titulo||a.empresaNome)}</div>`).join('')}
      ${ms.length>3?`<div class="cal-more">+${ms.length-3} mais</div>`:''}</div>`;
  }
  const sel = CAL.sel ? meetingsOnDay(items, CAL.sel) : [];
  const noMes = items.filter(a=>a.data && a.data.slice(0,7)===`${y}-${pad(m+1)}`).length;
  return `<div class="cal-head"><button class="btn btn-ghost btn-sm" data-cal-nav="-1">‹</button><h4>${MESES[m]} ${y} <span class="hint">· ${noMes} compromisso(s)</span></h4><button class="btn btn-ghost btn-sm" data-cal-nav="1">›</button><button class="btn btn-ghost btn-sm" data-cal-nav="hoje">Hoje</button></div>
    <div class="cal-grid">${['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'].map(d=>`<div class="cal-dow">${d}</div>`).join('')}${cells}</div>
    <div class="cal-legend"><span class="cal-ev agendada">agendada</span> <span class="cal-ev realizada">realizada</span> <span class="cal-ev agendada ext">evento externo</span></div>
    ${CAL.sel?`<div class="cal-day-detail"><h4>${fmtDate(CAL.sel)}</h4>${sel.length? sel.map(a=>`<div class="mini-row" style="cursor:pointer" data-meet="${a.id}"><span class="k"><b class="mono">${a.horario||'—'}</b> · ${escapeHtml(a.titulo||a.empresaNome)}</span><span class="v" style="font-weight:400;">${escapeHtml(a.local||'')}</span></div>`).join('') : '<div class="hint">Nenhuma reunião neste dia.</div>'}</div>`:''}`;
}
function renderMeetingTable(items){
  if(!items.length) return '<div class="empty">Nenhuma reunião registrada.</div>';
  return `<table><thead><tr><th>Data</th><th>Hora</th><th>Reunião</th><th>Local</th><th>Status</th><th>Objetivo / Resultado</th><th>Responsável</th></tr></thead><tbody>
    ${items.map(a=>`<tr class="clickable" data-meet="${a.id}"><td>${fmtDate(a.data)}${a.dataFim?' – '+fmtDate(a.dataFim):''}</td><td class="mono">${a.horario||'—'}</td><td><b>${escapeHtml(a.titulo||a.empresaNome)}</b></td><td>${escapeHtml(a.local||'—')}</td><td>${reuniaoStatus(a)}</td><td>${escapeHtml([a.objetivo,a.resultado].filter(Boolean).join(' · ')||'—')}</td><td><span class="badge-resp">${a.responsavel||''}</span></td></tr>`).join('')}
    </tbody></table>`;
}
function openMeetingDetail(a){
  const root=document.getElementById('modal-root');
  const row=(k,v)=>v?`<div class="mini-row"><span class="k">${k}</span><span class="v" style="font-weight:400;">${escapeHtml(v)}</span></div>`:'';
  root.innerHTML=`<div class="modal-overlay" id="ovm"><div class="modal"><div class="modal-head"><h3>${escapeHtml(a.titulo||a.empresaNome)}</h3><button class="close-x" id="closem">✕</button></div>
   <div class="modal-body">${row('Empresa',a.empresaNome)}${row('Data',fmtDate(a.data)+(a.dataFim?' – '+fmtDate(a.dataFim):''))}${row('Horário',(a.horario||'')+(a.horarioFim?' – '+a.horarioFim:''))}${row('Local',a.local)}${row('Status',reuniaoStatus(a))}${row('Responsável',a.responsavel)}${row('Participantes (empresa)',a.participantesEmpresa)}${row('Objetivo',a.objetivo)}${row('Resultado',a.resultado)}${row('Próxima ação',a.proximaAcao)}
   ${a.seed?'<div class="hint" style="margin-top:10px;">Vem da agenda do Outlook/Teams. Objetivo e resultado podem ser pedidos ao Claude ou registrados em "+ Registrar reunião".</div>':''}</div>
   <div class="modal-foot">${a.empresaId&&ST.registry[a.empresaId]?'<button class="btn btn-ghost" id="open-co">Abrir empresa</button>':''}<button class="btn btn-primary" id="cancelm">Fechar</button></div></div></div>`;
  const close=()=>root.innerHTML='';
  document.getElementById('closem').onclick=close; document.getElementById('cancelm').onclick=close;
  document.getElementById('ovm').addEventListener('click',e=>{ if(e.target.id==='ovm') close(); });
  const oc=document.getElementById('open-co'); if(oc) oc.onclick=()=>{ close(); openCompanyDrawer(a.empresaId); };
}

function openMeetingModal(companyId, companyName){
  const root = document.getElementById('modal-root');
  const companyOptions = companiesList().sort((a,b)=>a.cache.n.localeCompare(b.cache.n)).map(c=>`<option value="${c.id}" data-n="${escapeHtml(c.cache.n)}" ${c.id===companyId?'selected':''}>${escapeHtml(c.cache.n)}</option>`).join('');
  root.innerHTML = `
  <div class="modal-overlay" id="ovm">
    <div class="modal">
      <div class="modal-head"><h3>Registrar reunião</h3><button class="close-x" id="closem">✕</button></div>
      <div class="modal-body">
        <div class="form-grid">
          <div class="fld"><label>Empresa</label><select id="m-empresa">${companyId?'':'<option value="">Selecione...</option>'}${companyOptions}</select></div>
          <div class="fld"><label>Data</label><input type="date" id="m-data" value="${todayISO()}"/></div>
          <div class="fld"><label>Responsável CCIB</label><select id="m-resp"><option value="pedro">Pedro</option><option value="rafaela">Rafaela</option></select></div>
          <div class="fld"><label>Status</label><select id="m-status"><option value="realizada">Realizada</option><option value="agendada">Agendada</option></select></div>
          <div class="fld" style="grid-column:1/-1;"><label>Participantes (empresa)</label><input type="text" id="m-participantes" placeholder="Nomes dos participantes"/></div>
          <div class="fld" style="grid-column:1/-1;"><label>Objetivo</label><input type="text" id="m-objetivo" placeholder="Ex: apresentar proposta de associação"/></div>
          <div class="fld" style="grid-column:1/-1;"><label>Resultado</label><textarea id="m-resultado" placeholder="O que foi decidido / discutido"></textarea></div>
          <div class="fld"><label>Próxima ação</label><input type="text" id="m-proxima" placeholder="Ex: enviar proposta"/></div>
          <div class="fld"><label>Data do follow-up</label><input type="date" id="m-followdata"/></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" id="cancelm">Cancelar</button><button class="btn btn-primary" id="savem">Salvar reunião</button></div>
    </div>
  </div>`;
  const close = ()=> root.innerHTML='';
  document.getElementById('closem').onclick = close;
  document.getElementById('cancelm').onclick = close;
  document.getElementById('ovm').addEventListener('click', e=>{ if(e.target.id==='ovm') close(); });
  document.getElementById('savem').onclick = ()=>{
    const sel = document.getElementById('m-empresa');
    const empId = sel.value; if(!empId){ alert('Selecione a empresa.'); return; }
    const empName = sel.selectedOptions[0].dataset.n || sel.selectedOptions[0].textContent;
    const activity = {
      id: uid(), tipo:'reuniao', empresaId: empId, empresaNome: empName,
      data: document.getElementById('m-data').value,
      participantesEmpresa: document.getElementById('m-participantes').value,
      objetivo: document.getElementById('m-objetivo').value,
      resultado: document.getElementById('m-resultado').value,
      proximaAcao: document.getElementById('m-proxima').value,
      dataFollowUp: document.getElementById('m-followdata').value || null,
      responsavel: document.getElementById('m-resp').value,
      status: document.getElementById('m-status').value === 'agendada' ? 'agendado' : 'concluído-parcial'
    };
    ST.activities.push(activity);
    persistActivities();
    close();
    renderAll();
    if(document.getElementById('drawer-activities')) renderDrawerActivities(empId);
  };
}

/* ============================= PIPELINE ============================= */
function renderPipeline(){
  const el = document.getElementById('tab-pipeline'); if(!el) return;
  const list = applyFilters(companiesList());
  const cols = [STAGE_CONTATO].concat(STAGES).map(stage=>{
    const items = list.filter(c=>c.cache.s!=='lost' && stageOf(c)===stage);
    return `<div class="kanban-col"><h4><span>${stage}</span><span class="mono">${items.length}</span></h4>
      ${items.map(c=>`<div class="kanban-card" data-id="${c.id}">
        <div class="co-name">${escapeHtml(c.cache.n)}</div>
        <div class="hint">${escapeHtml(c.cache.ind||'')}</div>
        <select data-stage-for="${c.id}">${[STAGE_CONTATO].concat(STAGES).map(s=>`<option value="${s}" ${s===stage?'selected':''}>${s}</option>`).join('')}</select>
      </div>`).join('')}
    </div>`;
  }).join('');
  const perdidos = list.filter(c=>c.cache.s==='lost');
  const colPerdidos = `<div class="kanban-col"><h4><span>Negócio perdido</span><span class="mono">${perdidos.length}</span></h4>
      ${perdidos.map(c=>`<div class="kanban-card" data-id="${c.id}">
        <div class="co-name">${escapeHtml(c.cache.n)}</div>
        <div class="hint">${escapeHtml(c.cache.ind||'')}</div>
        <div class="hint">perdido no HubSpot</div>
      </div>`).join('')}
    </div>`;
  el.innerHTML = `<div class="panel"><div class="panel-head"><h3>Funil próprio da Regional São Paulo</h3><span class="hint">arraste não é suportado — mude a etapa pelo seletor no card</span></div>
    <div class="panel-body"><div class="kanban">${cols}${colPerdidos}</div></div></div>`;
  el.querySelectorAll('[data-stage-for]').forEach(sel=>{
    sel.addEventListener('click', e=>e.stopPropagation());
    sel.addEventListener('change', ()=>{
      const id = sel.dataset.stageFor;
      ST.registry[id].stage = sel.value;
      persistRegistry();
      renderPipeline();
    });
  });
  el.querySelectorAll('.kanban-card').forEach(card=>{
    card.addEventListener('click', (e)=>{ if(e.target.tagName==='SELECT') return; openCompanyDrawer(card.dataset.id); });
  });
}

/* ============================= FOLLOW-UPS ============================= */
function renderFollowups(){
  const el = document.getElementById('tab-followups'); if(!el) return;
  const items = ST.activities.filter(a=>a.dataFollowUp);
  const atrasados = items.filter(a=>daysBetween(a.dataFollowUp)<0 && a.status!=='concluído');
  const hoje = items.filter(a=>daysBetween(a.dataFollowUp)===0 && a.status!=='concluído');
  const proximos = items.filter(a=>daysBetween(a.dataFollowUp)>0 && a.status!=='concluído');
  const concluidos = items.filter(a=>a.status==='concluído');
  function block(title, arr, tagClass){
    return `<div class="panel"><div class="panel-head"><h3>${title} (${arr.length})</h3></div><div class="panel-body">
      ${arr.length? arr.sort((a,b)=>new Date(a.dataFollowUp)-new Date(b.dataFollowUp)).map(a=>`
      <div class="mini-row"><span class="k"><b>${escapeHtml(a.empresaNome)}</b> · ${escapeHtml(a.proximaAcao||'follow-up')} <span class="hint">(${fmtDate(a.dataFollowUp)})</span></span>
      <span class="v"><span class="tag ${tagClass}">${a.responsavel||''}</span> <button class="link-btn" data-done="${a.id}" style="margin-left:8px;">marcar concluído</button></span></div>`).join('')
      : '<div class="empty">Nada por aqui.</div>'}
      </div></div>`;
  }
  el.innerHTML = block('Atrasados', atrasados,'tag-late') + block('Hoje', hoje,'tag-soon') + block('Próximos', proximos,'tag-ok') + block('Concluídos recentemente', concluidos.slice(-8),'tag-ok');
  el.querySelectorAll('[data-done]').forEach(btn=>btn.addEventListener('click', ()=>{
    const act = ST.activities.find(a=>a.id===btn.dataset.done);
    if(act){ act.status='concluído'; persistActivities(); renderFollowups(); }
  }));
}

/* ============================= EVENTOS ============================= */
function eventoCard(ev, realizado){
  const line = (k,v)=> v ? `<div class="ev-line"><span class="ev-k">${k}</span>${escapeHtml(v)}</div>` : '';
  const quando = [ev.data?'':ev.dataPrevista, ev.horario, ev.local].filter(Boolean).join(' · ');
  const tagCls = ev.tag==='Em definição' ? 'tag-navy' : 'tag-ok';
  return `<div class="evento-card ${realizado?'done':''}">
    <div class="ev-date mono">${evDataLabel(ev)}<span class="ev-year">${ev.data? ev.data.slice(0,4):(ev.dataPrevista?'a definir':'')}</span></div>
    <div class="ev-name">${escapeHtml(ev.nome)}</div>
    ${quando? `<div class="ev-line">${escapeHtml(quando)}</div>` : ''}
    ${line('Formato', ev.formato)}
    ${line('Organização / parceiros', ev.parceiros)}
    ${line('Temas', ev.temas)}
    ${line('Painel / programação', ev.painel)}
    ${line('Empresas', ev.empresasParticipantes)}
    ${line('Participantes', ev.numParticipantes)}
    ${line('Resultado', ev.resultado)}
    ${line('Observações', ev.observacoes)}
    ${ev.tag? `<div class="ev-tag"><span class="tag ${tagCls}">${escapeHtml(ev.tag)}</span></div>` : ''}
  </div>`;
}
function renderEventos(){
  const el = document.getElementById('tab-eventos'); if(!el) return;
  const prox = proximosEventos(), real = eventosRealizados();
  el.innerHTML = `
    <div class="panel"><div class="panel-head"><h3>Próximos eventos (${prox.length})</h3><button class="btn btn-accent btn-sm" id="btn-new-evento">+ Novo evento</button></div>
      <div class="panel-body">${prox.length? `<div class="evento-grid">${prox.map(ev=>eventoCard(ev,false)).join('')}</div>` : '<div class="empty">Nenhum evento agendado.</div>'}</div></div>
    <div class="panel"><div class="panel-head"><h3>Eventos realizados (${real.length})</h3></div>
      <div class="panel-body">${real.length? `<div class="evento-grid">${real.map(ev=>eventoCard(ev,true)).join('')}</div>` : '<div class="empty">Nenhum evento realizado registrado ainda.</div>'}</div></div>`;
  document.getElementById('btn-new-evento').onclick = openEventoModal;
}
function openEventoModal(){
  const root = document.getElementById('modal-root');
  root.innerHTML = `<div class="modal-overlay" id="ove"><div class="modal">
    <div class="modal-head"><h3>Novo evento / iniciativa</h3><button class="close-x" id="closee">✕</button></div>
    <div class="modal-body"><div class="form-grid">
      <div class="fld" style="grid-column:1/-1;"><label>Nome do evento</label><input type="text" id="ev-nome"/></div>
      <div class="fld"><label>Data</label><input type="date" id="ev-data" value="${todayISO()}"/></div>
      <div class="fld"><label>Horário</label><input type="text" id="ev-horario" placeholder="Ex: 10h às 13h"/></div>
      <div class="fld"><label>Local</label><input type="text" id="ev-local"/></div>
      <div class="fld"><label>Formato</label><input type="text" id="ev-formato" placeholder="Presencial, híbrido..."/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Organização / parceiros</label><input type="text" id="ev-parceiros"/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Temas</label><input type="text" id="ev-temas"/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Painel / programação</label><input type="text" id="ev-painel"/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Empresas participantes</label><input type="text" id="ev-empresas" placeholder="separadas por vírgula"/></div>
      <div class="fld"><label>Nº de participantes</label><input type="number" id="ev-num"/></div>
      <div class="fld"><label>Situação / custo</label><input type="text" id="ev-tag" placeholder="Ex: Sem custo para a Câmara"/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Resultado / oportunidades geradas</label><textarea id="ev-resultado"></textarea></div>
      <div class="fld" style="grid-column:1/-1;"><label>Observações</label><textarea id="ev-obs"></textarea></div>
    </div></div>
    <div class="modal-foot"><button class="btn btn-ghost" id="cancele">Cancelar</button><button class="btn btn-primary" id="savee">Salvar evento</button></div>
  </div></div>`;
  const close = ()=> root.innerHTML='';
  document.getElementById('closee').onclick = close;
  document.getElementById('cancele').onclick = close;
  document.getElementById('ove').addEventListener('click', e=>{ if(e.target.id==='ove') close(); });
  document.getElementById('savee').onclick = ()=>{
    const v = id => document.getElementById(id).value;
    ST.eventos.push({
      id: uid(), nome: v('ev-nome') || 'Evento sem nome', data: v('ev-data'), horario: v('ev-horario'),
      local: v('ev-local'), formato: v('ev-formato'), parceiros: v('ev-parceiros'), temas: v('ev-temas'),
      painel: v('ev-painel'), empresasParticipantes: v('ev-empresas'), numParticipantes: v('ev-num'),
      tag: v('ev-tag'), resultado: v('ev-resultado'), observacoes: v('ev-obs')
    });
    persistEventos(); close(); renderAll();
  };
}

/* ============================= CONEXÕES ============================= */
function renderConexoes(){
  const el = document.getElementById('tab-conexoes'); if(!el) return;
  el.innerHTML = `<div class="panel"><div class="panel-head"><h3>Mapa de conexões</h3></div><div class="panel-body" id="conexao-svg-holder"></div></div>
    <div class="panel"><div class="panel-head"><h3>Conexões registradas (${ST.conexoes.length})</h3><button class="btn btn-accent btn-sm" id="btn-new-conexao">+ Nova conexão</button></div>
    <div class="panel-body">
    ${ST.conexoes.length? ST.conexoes.slice().reverse().map(cx=>`
      <div class="mini-row" style="flex-direction:column;align-items:flex-start;gap:4px;padding:10px 0;">
        <div style="display:flex;justify-content:space-between;width:100%;"><b>${escapeHtml(cx.empresaA)} ↔ ${escapeHtml(cx.empresaB)}</b><span class="hint">${fmtDate(cx.data)}</span></div>
        <div class="hint">Motivo: ${escapeHtml(cx.motivo||'—')} · Responsável: ${escapeHtml(cx.responsavel||'—')}</div>
        <div>${escapeHtml(cx.resultado||'')}</div>
      </div>`).join('') : '<div class="empty">Nenhuma conexão registrada ainda.</div>'}
    </div></div>`;
  document.getElementById('btn-new-conexao').onclick = openConexaoModal;
  renderConexaoSvg();
}
function renderConexaoSvg(){
  const holder = document.getElementById('conexao-svg-holder'); if(!holder) return;
  if(!ST.conexoes.length){ holder.innerHTML = '<div class="empty">O mapa aparece aqui assim que houver conexões registradas.</div>'; return; }
  const names = Array.from(new Set(ST.conexoes.flatMap(c=>[c.empresaA,c.empresaB])));
  const cx0=280, cy0=140, r=105;
  const pos = {};
  names.forEach((n,i)=>{ const ang = (i/names.length)*2*Math.PI - Math.PI/2; pos[n] = {x:cx0+r*Math.cos(ang), y:cy0+r*Math.sin(ang)}; });
  const lines = ST.conexoes.map(c=>{
    const a=pos[c.empresaA], b=pos[c.empresaB];
    return `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#E8A33D" stroke-width="1.6" opacity="0.7"/>`;
  }).join('');
  const nodes = names.map(n=>{
    const p = pos[n];
    return `<circle cx="${p.x}" cy="${p.y}" r="5.5" fill="#0E2038"/><text x="${p.x}" y="${p.y-10}" font-size="10.5" font-family="Inter,sans-serif" fill="#101826" text-anchor="middle">${escapeHtml(n).slice(0,18)}</text>`;
  }).join('');
  holder.innerHTML = `<svg viewBox="0 0 560 280" width="100%" height="280">${lines}${nodes}</svg>`;
}
function openConexaoModal(){
  const root = document.getElementById('modal-root');
  root.innerHTML = `<div class="modal-overlay" id="ovx"><div class="modal">
    <div class="modal-head"><h3>Nova conexão empresarial</h3><button class="close-x" id="closex">✕</button></div>
    <div class="modal-body"><div class="form-grid">
      <div class="fld"><label>Empresa A</label><input type="text" id="cx-a"/></div>
      <div class="fld"><label>Empresa B</label><input type="text" id="cx-b"/></div>
      <div class="fld"><label>Data</label><input type="date" id="cx-data" value="${todayISO()}"/></div>
      <div class="fld"><label>Responsável</label><select id="cx-resp"><option value="pedro">Pedro</option><option value="rafaela">Rafaela</option></select></div>
      <div class="fld" style="grid-column:1/-1;"><label>Motivo da conexão</label><input type="text" id="cx-motivo"/></div>
      <div class="fld" style="grid-column:1/-1;"><label>Resultado / oportunidade gerada</label><textarea id="cx-resultado"></textarea></div>
    </div></div>
    <div class="modal-foot"><button class="btn btn-ghost" id="cancelx">Cancelar</button><button class="btn btn-primary" id="savex">Salvar conexão</button></div>
  </div></div>`;
  const close = ()=> root.innerHTML='';
  document.getElementById('closex').onclick = close;
  document.getElementById('cancelx').onclick = close;
  document.getElementById('ovx').addEventListener('click', e=>{ if(e.target.id==='ovx') close(); });
  document.getElementById('savex').onclick = ()=>{
    ST.conexoes.push({
      id: uid(), empresaA: document.getElementById('cx-a').value, empresaB: document.getElementById('cx-b').value,
      data: document.getElementById('cx-data').value, responsavel: document.getElementById('cx-resp').value,
      motivo: document.getElementById('cx-motivo').value, resultado: document.getElementById('cx-resultado').value
    });
    persistConexoes(); close(); renderAll();
  };
}

/* ============================= FILTER WIRING ============================= */
function wireFilters(){
  document.getElementById('f-setor').addEventListener('change', e=>{ ST.filters.setor=e.target.value; renderAll(); });
  document.getElementById('f-status').addEventListener('change', e=>{ ST.filters.status=e.target.value; renderAll(); });
  document.getElementById('f-resp').addEventListener('change', e=>{ ST.filters.resp=e.target.value; renderAll(); });
  document.getElementById('f-periodo').addEventListener('change', e=>{ ST.filters.periodo=e.target.value; renderAll(); });
  let bt=null;
  document.getElementById('f-busca').addEventListener('input', e=>{ clearTimeout(bt); bt=setTimeout(()=>{ ST.filters.busca=e.target.value; renderAll(); }, 300); });
  document.getElementById('btn-sync-all').addEventListener('click', openSyncInfoModal);
}

/* ============================= INIT ============================= */
async function init(){
  await loadAll();
  try{
    const res = await fetch('data/snapshot.json', {cache:'no-store'});
    if(!res.ok) throw new Error('HTTP '+res.status);
    HUBSPOT_SNAPSHOT = await res.json();
    // Sempre aplica o retrato mais recente trazido do HubSpot — isso atualiza
    // os números (setor, status, valores, contatos) mas preserva o que a equipe já editou
    // localmente (etapa do funil, responsável, reuniões, follow-ups, eventos, conexões).
    applySnapshot();
  }catch(e){
    console.error('Não foi possível carregar data/snapshot.json', e);
    document.getElementById('error-banner-holder').innerHTML =
      '<div class="error-banner"><div style="flex:1;"><b>Não foi possível carregar os dados do HubSpot</b>'+
      'O arquivo data/snapshot.json não pôde ser lido ('+escapeHtml(e.message)+'). '+
      'Verifique se o arquivo existe no repositório e foi publicado corretamente.</div></div>';
  }
  try{
    const r = await fetch('data/apenas-contato.json', {cache:'no-store'});
    if(r.ok){ (await r.json()).forEach(x=>{ APENAS_CONTATO[x.id]=true; }); }
  }catch(e){ console.warn('data/apenas-contato.json não carregado', e); }
  try{
    const r = await fetch('data/eventos.json', {cache:'no-store'});
    if(r.ok){
      const seed = await r.json();
      // eventos do repositório (seed) + eventos cadastrados pela equipe neste navegador
      const doUsuario = ST.eventos.filter(e=>!e.seed);
      ST.eventos = seed.map(e=>({...e, seed:true})).concat(doUsuario);
    }
  }catch(e){ console.warn('data/eventos.json não carregado', e); }
  try{
    const r = await fetch('data/reunioes.json', {cache:'no-store'});
    if(r.ok){
      const seed = await r.json();
      ST.activities = seed.map(m=>({...m, seed:true})).concat(ST.activities.filter(a=>!a.seed));
    }
  }catch(e){ console.warn('data/reunioes.json não carregado', e); }
  wireFilters();
  renderAll();
}
init();

})();
